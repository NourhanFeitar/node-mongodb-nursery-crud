const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
require("./../models/TeacherModel");

const teacherSchema = mongoose.model("Teacher");

exports.login = async function (request, response, next) {
  //static user email: x@x/com , password 123

  let email = request.body.email;
  let password = request.body.password;

  let teacher = await teacherSchema.findOne({ email: email });
  try {
    if (teacher == null) {
      throw new Error("This email doesn't exist, please sign up.");
    }

    if (teacher.password != password) {
      throw new Error("Incorrect password for this email.");
    }

    let role = "";
    if (teacher.email == "may@gmail.com") {
      role = "admin";
    } else {
      role = "teacher";
    }
    let payload = {
        id: teacher._id,
        role: role,
        userName: teacher.email
    }
    const token = jwt.sign(
      payload,
      "NurserySystem",
      { expiresIn: "3h" }
    ); // secret key and token expiration

    response.status(200).json({ payload: payload, token });
  } catch (e) {
    next(e);
  }

  //   if (request.body.email == "x@x.com" && request.body.password == "123") {
  //     const token = jwt.sign(
  //       {
  //         id: 1,
  //         role: "admin",
  //         userName: "x",
  //       },
  //       "NurserySystem",
  //       { expiresIn: "1h" }
  //     ); // secret key and token expiration

  //     response.status(200).json({ data: "OK", token });
  //   } else {
  //     //eno msh admin but a teacher only
  //     teacherSchema
  //       .findOne({ email: request.body.email, password: request.body.password })
  //       .then((user) => {
  //         if (user == null) {
  //           throw new Error("Username or password incorrect..");
  //         }

  //         const token = jwt.sign(
  //           {
  //             id: user._id,
  //             role: "Teacher",
  //           },
  //           "NurserySystem",
  //           { expiresIn: "1h" }
  //         );

  //         response.status(200).json({ data: "OK", token });
  //       })
  //       .catch((error) => next(error));
  //   }
};
